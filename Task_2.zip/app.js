const state = { currentUser: null, posts: [], suggestions: [], view: 'home', sort: 'latest', search: '', image: '', saved: new Set(JSON.parse(localStorage.getItem('jan-saved') || '[]')) };
const $ = (selector) => document.querySelector(selector);
const escapeHtml = (value) => String(value).replace(/[&<>'"]/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;', '"': '&quot;' }[character]));
const formatTime = (date) => {
  if (/hour|day|minute/.test(date)) return date;
  const created = new Date(date.replace(' ', 'T') + 'Z');
  const minutes = Math.max(1, Math.floor((Date.now() - created) / 60000));
  if (minutes < 60) return `${minutes}m`;
  if (minutes < 1440) return `${Math.floor(minutes / 60)}h`;
  return `${Math.floor(minutes / 1440)}d`;
};
const avatar = (user, className = 'avatar', id = '') => `<div${id ? ` id="${id}"` : ''} class="${className}" style="background:${user.accent || '#4b6f78'}">${escapeHtml(user.avatar)}</div>`;
let authMode = 'login';

async function request(url, options = {}) {
  const response = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...options });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'Something went wrong.');
  return data;
}
function showToast(message) { const toast = $('#toast'); toast.textContent = message; toast.classList.add('show'); setTimeout(() => toast.classList.remove('show'), 2400); }
function updateProfile(user) {
  state.currentUser = user;
  $('#profileName').textContent = user.name;
  $('#profileHandle').textContent = `@${user.username}`;
  $('#profileBio').textContent = user.bio;
  $('#followerCount').textContent = user.followers;
  $('#followingCount').textContent = user.following;
  [['profileAvatar', 'avatar-large'], ['composerAvatar', '' ], ['headerAvatar', 'avatar-small']].forEach(([id, sizeClass]) => {
    const element = $(`#${id}`);
    element.textContent = user.avatar;
    element.style.background = user.accent || '#4b6f78';
    if (sizeClass) element.classList.add(sizeClass);
  });
}
function renderSuggestions() {
  $('#suggestions').innerHTML = state.suggestions.map((user) => `<div class="person">${avatar(user)}<div class="person-info"><strong>${escapeHtml(user.name)}</strong><span>@${escapeHtml(user.username)}</span></div><button class="follow-button ${user.is_following ? 'following' : ''}" data-follow="${user.id}">${user.is_following ? 'Following' : 'Follow'}</button></div>`).join('');
}
function renderPosts(posts = state.posts) {
  $('#feedList').innerHTML = posts.length ? posts.map((post, index) => `<article class="post panel" id="post-${post.id}" style="animation-delay:${index * 60}ms"><div class="post-head">${avatar(post)}<div><div class="post-author"><strong>${escapeHtml(post.name)}</strong><span>@${escapeHtml(post.username)}</span></div><div class="post-time">${formatTime(post.createdAt)} ago</div></div><button class="post-more" aria-label="More options">···</button></div><p class="post-content">${escapeHtml(post.content).replace(/\n/g, '<br>')}</p>${post.image ? `<img class="post-image" src="${escapeHtml(post.image)}" alt="Image shared by ${escapeHtml(post.name)}">` : ''}${post.comments.length ? `<div class="comment-list">${post.comments.map((comment) => `<div class="comment">${avatar(comment, 'avatar avatar-small')}<span><strong>${escapeHtml(comment.name)}</strong>${escapeHtml(comment.content)}</span></div>`).join('')}</div>` : ''}<div class="post-actions"><button class="post-action ${post.liked ? 'liked' : ''}" data-like="${post.id}"><span>${post.liked ? '♥' : '♡'}</span>${post.likes || ''}</button><button class="post-action comment-toggle" data-comments="${post.id}"><span>◌</span>${post.commentsCount || ''}</button><button class="post-action ${state.saved.has(post.id) ? 'saved' : ''}" data-save="${post.id}"><span>${state.saved.has(post.id) ? '◆' : '◇'}</span>${state.saved.has(post.id) ? 'Saved' : 'Save'}</button><button class="post-action" data-share="${post.id}"><span>↗</span>Share</button></div><form class="comment-form" data-form="${post.id}"><input maxlength="280" placeholder="Write a thoughtful reply..."><button type="submit">Reply</button></form></article>`).join('') : '<div class="loading">No posts here yet. Try another view or start the conversation.</div>';
}
function visiblePosts() { let posts = [...state.posts]; if (state.view === 'saved') posts = posts.filter((post) => state.saved.has(post.id)); if (state.view === 'profile') posts = posts.filter((post) => post.userId === state.currentUser.id); if (state.search) posts = posts.filter((post) => `${post.name} ${post.username} ${post.content}`.toLowerCase().includes(state.search)); if (state.sort === 'popular') posts.sort((a, b) => b.likes - a.likes); return posts; }
function renderFeed() { renderPosts(visiblePosts()); }
function setView(view) { state.view = view; document.querySelectorAll('.nav-item').forEach((item) => item.classList.toggle('active', item.dataset.view === view)); $('#feedTitle').textContent = view === 'saved' ? 'Saved posts' : view === 'profile' ? 'Your profile' : view === 'explore' ? 'Explore' : 'Your feed'; renderFeed(); }
function showApp() { $('#loginScreen').classList.add('hidden'); }
function showLogin() { $('#loginScreen').classList.remove('hidden'); }
async function load() { const data = await request('/api/bootstrap'); updateProfile(data.currentUser); $('#adminButton').classList.toggle('visible', data.currentUser.role === 'admin'); state.suggestions = data.suggested; renderSuggestions(); state.posts = data.posts; renderFeed(); showApp(); }
async function refreshFollow(userId, button) { try { const data = await request(`/api/users/${userId}/follow`, { method: 'POST' }); updateProfile(data.currentUser); state.suggestions = data.suggested; renderSuggestions(); showToast(button.classList.contains('following') ? 'Follow removed' : 'Now following'); } catch (error) { showToast(error.message); } }

$('#postInput').addEventListener('input', (event) => { $('#charCount').textContent = `${event.target.value.length} / 500`; });
$('#postButton').addEventListener('click', async () => { const input = $('#postInput'); const content = input.value.trim(); if (!content && !state.image) return showToast('Write something or add a photo first.'); try { const data = await request('/api/posts', { method: 'POST', body: JSON.stringify({ content: content || 'Shared a photo', image: state.image }) }); input.value = ''; state.image = ''; $('#imageInput').value = ''; $('#imagePreview').innerHTML = ''; $('#charCount').textContent = '0 / 500'; state.posts = data.posts; renderFeed(); showToast('Your post is live.'); } catch (error) { showToast(error.message); } });
$('#focusComposer').addEventListener('click', () => { $('#postInput').focus(); window.scrollTo({ top: 0, behavior: 'smooth' }); });
document.querySelectorAll('.nav-item').forEach((item) => item.addEventListener('click', () => setView(item.dataset.view)));
$('#headerAvatar').addEventListener('click', () => setView('profile'));
$('#viewProfile').addEventListener('click', () => setView('profile'));
$('#filterButton').addEventListener('click', () => { state.sort = state.sort === 'latest' ? 'popular' : 'latest'; $('#filterButton').innerHTML = `${state.sort === 'latest' ? 'Latest' : 'Popular'} <span>⌄</span>`; renderFeed(); });
$('#notificationsButton').addEventListener('click', () => showToast('You are all caught up.'));
$('#messagesButton').addEventListener('click', () => showToast('Messages are coming soon.'));
$('#logoutButton').addEventListener('click', async () => { await request('/api/auth/logout', { method: 'POST' }); state.currentUser = null; showLogin(); showToast('You are logged out.'); });
$('#adminButton').addEventListener('click', async () => { try { const stats = await request('/api/admin/stats'); showToast(`Admin view: ${stats.users} users, ${stats.posts} posts, ${stats.comments} comments.`); } catch (error) { showToast(error.message); } });
$('#aboutLink').addEventListener('click', (event) => { event.preventDefault(); showToast('Jan is a quieter social space for thoughtful updates.'); });
$('#privacyLink').addEventListener('click', (event) => { event.preventDefault(); showToast('Your demo data stays in this local app.'); });
$('#suggestions').addEventListener('click', (event) => { const button = event.target.closest('[data-follow]'); if (button) refreshFollow(button.dataset.follow, button); });
$('#feedList').addEventListener('click', async (event) => { const like = event.target.closest('[data-like]'); const save = event.target.closest('[data-save]'); const commentToggle = event.target.closest('[data-comments]'); const share = event.target.closest('[data-share]'); if (like) { try { const data = await request(`/api/posts/${like.dataset.like}/like`, { method: 'POST' }); state.posts = data.posts; renderFeed(); } catch (error) { showToast(error.message); } } if (save) { const postId = Number(save.dataset.save); state.saved.has(postId) ? state.saved.delete(postId) : state.saved.add(postId); localStorage.setItem('jan-saved', JSON.stringify([...state.saved])); renderFeed(); showToast(state.saved.has(postId) ? 'Post saved.' : 'Post removed from saved.'); } if (commentToggle) { const form = document.querySelector(`[data-form="${commentToggle.dataset.comments}"]`); form.classList.toggle('open'); if (form.classList.contains('open')) form.querySelector('input').focus(); } if (share) { await navigator.clipboard?.writeText(`${location.origin}/#post-${share.dataset.share}`); showToast('Link copied to clipboard.'); } });
$('#feedList').addEventListener('submit', async (event) => { event.preventDefault(); const form = event.target; const content = form.querySelector('input').value.trim(); if (!content) return; try { const data = await request(`/api/posts/${form.dataset.form}/comments`, { method: 'POST', body: JSON.stringify({ content }) }); state.posts = data.posts; renderFeed(); showToast('Reply added.'); } catch (error) { showToast(error.message); } });
$('#refreshPeople').addEventListener('click', async () => { await load(); showToast('Suggestions refreshed.'); });
$('#searchInput').addEventListener('input', (event) => { state.search = event.target.value.toLowerCase().trim(); renderFeed(); });
$('#photoPicker').addEventListener('click', () => $('#imageInput').click());
$('#clearImage').addEventListener('click', () => { state.image = ''; $('#imageInput').value = ''; $('#imagePreview').innerHTML = ''; });
$('#imageInput').addEventListener('change', (event) => { const file = event.target.files[0]; if (!file) return; if (!file.type.startsWith('image/')) return showToast('Please choose an image file.'); if (file.size > 7_500_000) return showToast('Choose an image smaller than 7.5 MB.'); const reader = new FileReader(); reader.onerror = () => showToast('This photo could not be read. Please choose it again.'); reader.onload = () => { state.image = reader.result; $('#imagePreview').innerHTML = `<img src="${escapeHtml(state.image)}" alt="Selected upload preview">`; }; reader.readAsDataURL(file); });
$('#authSwitch').addEventListener('click', () => { authMode = authMode === 'login' ? 'signup' : 'login'; const signup = authMode === 'signup'; $('#loginForm').classList.toggle('signup-mode', signup); $('#authTitle').textContent = signup ? 'Create your account.' : 'Welcome back.'; $('#authDescription').textContent = signup ? 'Choose a username and make a space that is yours.' : 'Log in to share moments, follow people, and join the conversation.'; $('#authSubmit').innerHTML = signup ? 'Sign up <span>↗</span>' : 'Log in <span>↗</span>'; $('#authSwitch').textContent = signup ? 'Already have an account? Log in' : 'Need an account? Sign up'; $('#loginHelp').textContent = signup ? 'Username: 3-24 letters, numbers, or underscores · Password: 6+ characters' : 'Demo user: ivychen / ivy123 · Admin: admin / admin123'; });
$('#loginForm').addEventListener('submit', async (event) => { event.preventDefault(); $('#loginError').textContent = ''; try { const endpoint = authMode === 'signup' ? '/api/auth/signup' : '/api/auth/login'; const body = { name: $('#loginName').value, username: $('#loginUsername').value, password: $('#loginPassword').value }; await request(endpoint, { method: 'POST', body: JSON.stringify(body) }); $('#loginPassword').value = ''; await load(); showToast(authMode === 'signup' ? 'Your account is ready.' : 'Welcome back to Jan.'); } catch (error) { $('#loginError').textContent = error.message; } });
request('/api/auth/me').then((data) => data.user ? load() : showLogin()).catch(() => showLogin());
