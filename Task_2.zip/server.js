const path = require('path');
const crypto = require('crypto');
const express = require('express');
const { DatabaseSync } = require('node:sqlite');

const app = express();
const preferredPort = Number(process.env.PORT) || 3000;
const db = new DatabaseSync(path.join(__dirname, 'pulse.db'));
db.exec('PRAGMA foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    username TEXT NOT NULL UNIQUE,
    bio TEXT NOT NULL DEFAULT '',
    avatar TEXT NOT NULL,
    accent TEXT NOT NULL DEFAULT '#d86f45',
    password_hash TEXT NOT NULL DEFAULT '',
    role TEXT NOT NULL DEFAULT 'user',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    image TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS likes (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, post_id)
  );
  CREATE TABLE IF NOT EXISTS follows (
    follower_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    following_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (follower_id, following_id),
    CHECK (follower_id != following_id)
  );
`);

try { db.exec("ALTER TABLE users ADD COLUMN password_hash TEXT NOT NULL DEFAULT ''"); } catch {}
try { db.exec("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'user'"); } catch {}
try { db.exec('ALTER TABLE posts ADD COLUMN image TEXT'); } catch {}

const hashPassword = (password) => crypto.createHash('sha256').update(password).digest('hex');

const seed = () => {
  const addUser = db.prepare('INSERT OR IGNORE INTO users (name, username, bio, avatar, accent, password_hash, role) VALUES (?, ?, ?, ?, ?, ?, ?)');
  const ivy = addUser.run('Ivy Chen', 'ivychen', 'Designing quiet corners of the internet. Product, plants, and good questions.', 'IC', '#d86f45', hashPassword('ivy123'), 'user').lastInsertRowid || db.prepare('SELECT id FROM users WHERE username = ?').get('ivychen').id;
  const maya = addUser.run('Maya Patel', 'mayapatel', 'Creative technologist collecting small details from big cities.', 'MP', '#4b6f78', hashPassword('maya123'), 'user').lastInsertRowid || db.prepare('SELECT id FROM users WHERE username = ?').get('mayapatel').id;
  const theo = addUser.run('Theo Brooks', 'theobrooks', 'Writer, weekend cook, permanently curious.', 'TB', '#bd8b49', hashPassword('theo123'), 'user').lastInsertRowid || db.prepare('SELECT id FROM users WHERE username = ?').get('theobrooks').id;
  const june = addUser.run('June Park', 'junepark', 'Ceramics, sunlight, and the occasional long walk.', 'JP', '#7b6b83', hashPassword('june123'), 'user').lastInsertRowid || db.prepare('SELECT id FROM users WHERE username = ?').get('junepark').id;
  addUser.run('Jan Admin', 'admin', 'Site administrator', 'JA', '#202323', hashPassword('admin123'), 'admin');
  db.prepare("UPDATE users SET password_hash = ? WHERE username = ? AND password_hash = ''").run(hashPassword('ivy123'), 'ivychen');
  db.prepare("UPDATE users SET password_hash = ? WHERE username = ? AND password_hash = ''").run(hashPassword('maya123'), 'mayapatel');
  db.prepare("UPDATE users SET password_hash = ? WHERE username = ? AND password_hash = ''").run(hashPassword('theo123'), 'theobrooks');
  db.prepare("UPDATE users SET password_hash = ? WHERE username = ? AND password_hash = ''").run(hashPassword('june123'), 'junepark');
  db.prepare("UPDATE users SET password_hash = ?, role = 'admin' WHERE username = ? AND password_hash = ''").run(hashPassword('admin123'), 'admin');
  if (db.prepare('SELECT COUNT(*) AS count FROM posts').get().count > 0) return;
  const addPost = db.prepare('INSERT INTO posts (user_id, content, created_at) VALUES (?, ?, datetime(\'now\', ?))');
  const first = addPost.run(ivy, 'A tiny reminder: the best interfaces give your attention somewhere kind to land.', '-2 hours').lastInsertRowid;
  const second = addPost.run(maya, 'Found a bookshop tucked behind the station today. Three floors of dusty paperbacks and the exact kind of silence I needed.', '-5 hours').lastInsertRowid;
  const third = addPost.run(theo, 'What is everyone making for dinner this week? I am leaning toward something with too much garlic.', '-1 day').lastInsertRowid;
  db.prepare('INSERT INTO comments (post_id, user_id, content, created_at) VALUES (?, ?, ?, datetime(\'now\', ?))').run(first, maya, 'This is a lovely way to put it.', '-70 minutes');
  db.prepare('INSERT INTO comments (post_id, user_id, content, created_at) VALUES (?, ?, ?, datetime(\'now\', ?))').run(second, ivy, 'Adding this to my next wandering route.', '-4 hours');
  db.prepare('INSERT INTO likes (user_id, post_id) VALUES (?, ?)').run(maya, first);
  db.prepare('INSERT INTO likes (user_id, post_id) VALUES (?, ?)').run(theo, first);
  db.prepare('INSERT INTO likes (user_id, post_id) VALUES (?, ?)').run(ivy, second);
  db.prepare('INSERT INTO follows (follower_id, following_id) VALUES (?, ?)').run(ivy, maya);
  db.prepare('INSERT INTO follows (follower_id, following_id) VALUES (?, ?)').run(ivy, theo);
  db.prepare('INSERT INTO follows (follower_id, following_id) VALUES (?, ?)').run(maya, ivy);
  return { june };
};
seed();

app.use(express.json({ limit: '12mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const sessions = new Map();
const userSelect = `SELECT u.id, u.name, u.username, u.bio, u.avatar, u.accent, u.role,
  (SELECT COUNT(*) FROM follows WHERE following_id = u.id) AS followers,
  (SELECT COUNT(*) FROM follows WHERE follower_id = u.id) AS following,
  EXISTS(SELECT 1 FROM follows WHERE follower_id = ? AND following_id = u.id) AS is_following
  FROM users u`;

function getUserFromRequest(req) {
  const token = req.headers.cookie?.match(/jan_session=([^;]+)/)?.[1];
  return token ? sessions.get(token) : null;
}

function requireAuth(req, res, next) {
  const user = getUserFromRequest(req);
  if (!user) return res.status(401).json({ error: 'Please log in to continue.' });
  req.user = user;
  next();
}

function getPosts(currentUserId) {
  const posts = db.prepare(`SELECT p.id, p.content, p.created_at AS createdAt,
    p.image, u.id AS userId, u.name, u.username, u.avatar, u.accent,
    (SELECT COUNT(*) FROM likes WHERE post_id = p.id) AS likes,
    EXISTS(SELECT 1 FROM likes WHERE post_id = p.id AND user_id = ?) AS liked,
    (SELECT COUNT(*) FROM comments WHERE post_id = p.id) AS commentsCount
    FROM posts p JOIN users u ON u.id = p.user_id ORDER BY p.id DESC`).all(currentUserId);
  const commentQuery = db.prepare(`SELECT c.id, c.content, c.created_at AS createdAt, u.name, u.username, u.avatar, u.accent
    FROM comments c JOIN users u ON u.id = c.user_id WHERE c.post_id = ? ORDER BY c.id ASC`);
  return posts.map((post) => ({ ...post, comments: commentQuery.all(post.id) }));
}

app.post('/api/auth/login', (req, res) => {
  const username = String(req.body.username || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const user = db.prepare('SELECT id, name, username, role FROM users WHERE username = ? AND password_hash = ?').get(username, hashPassword(password));
  if (!user) return res.status(401).json({ error: 'Invalid username or password.' });
  const token = crypto.randomBytes(24).toString('hex');
  sessions.set(token, user);
  res.setHeader('Set-Cookie', `jan_session=${token}; HttpOnly; Path=/; SameSite=Lax`);
  res.json({ user });
});

app.post('/api/auth/signup', (req, res) => {
  const name = String(req.body.name || '').trim();
  const username = String(req.body.username || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (name.length < 2 || name.length > 60) return res.status(400).json({ error: 'Name must be between 2 and 60 characters.' });
  if (!/^[a-z0-9_]{3,24}$/.test(username)) return res.status(400).json({ error: 'Username must be 3-24 characters using letters, numbers, or underscores.' });
  if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters.' });
  if (db.prepare('SELECT 1 FROM users WHERE username = ?').get(username)) return res.status(409).json({ error: 'That username is already taken.' });
  const avatar = name.split(/\s+/).map((part) => part[0]).join('').slice(0, 2).toUpperCase();
  const accents = ['#d86f45', '#4b6f78', '#bd8b49', '#7b6b83'];
  const accent = accents[Math.floor(Math.random() * accents.length)];
  const result = db.prepare('INSERT INTO users (name, username, bio, avatar, accent, password_hash, role) VALUES (?, ?, ?, ?, ?, ?, ?)').run(name, username, 'New to Jan. Finding good conversations.', avatar, accent, hashPassword(password), 'user');
  const user = { id: result.lastInsertRowid, name, username, role: 'user' };
  const token = crypto.randomBytes(24).toString('hex');
  sessions.set(token, user);
  res.setHeader('Set-Cookie', `jan_session=${token}; HttpOnly; Path=/; SameSite=Lax`);
  res.status(201).json({ user });
});

app.post('/api/auth/logout', requireAuth, (req, res) => {
  const token = req.headers.cookie?.match(/jan_session=([^;]+)/)?.[1];
  sessions.delete(token);
  res.setHeader('Set-Cookie', 'jan_session=; Max-Age=0; Path=/');
  res.json({ ok: true });
});

app.get('/api/auth/me', (req, res) => {
  const user = getUserFromRequest(req);
  res.json({ user: user || null });
});

app.get('/api/bootstrap', requireAuth, (req, res) => {
  const currentUser = db.prepare(`${userSelect} WHERE u.id = ?`).get(req.user.id, req.user.id);
  const suggested = db.prepare(`${userSelect} WHERE u.id != ? ORDER BY is_following ASC, followers DESC LIMIT 3`).all(req.user.id, req.user.id);
  res.json({ currentUser, posts: getPosts(req.user.id), suggested });
});

app.post('/api/posts', requireAuth, (req, res) => {
  const content = String(req.body.content || '').trim();
  const image = String(req.body.image || '');
  if (!content || content.length > 500) return res.status(400).json({ error: 'Post must be between 1 and 500 characters.' });
  if (image && (!image.startsWith('data:image/') || image.length > 10_000_000)) return res.status(400).json({ error: 'Please choose a valid image smaller than 8 MB.' });
  db.prepare('INSERT INTO posts (user_id, content, image) VALUES (?, ?, ?)').run(req.user.id, content, image || null);
  res.status(201).json({ posts: getPosts(req.user.id) });
});

app.post('/api/posts/:id/like', requireAuth, (req, res) => {
  const postId = Number(req.params.id);
  const existing = db.prepare('SELECT 1 FROM likes WHERE user_id = ? AND post_id = ?').get(req.user.id, postId);
  if (existing) db.prepare('DELETE FROM likes WHERE user_id = ? AND post_id = ?').run(req.user.id, postId);
  else db.prepare('INSERT INTO likes (user_id, post_id) VALUES (?, ?)').run(req.user.id, postId);
  res.json({ posts: getPosts(req.user.id) });
});

app.post('/api/posts/:id/comments', requireAuth, (req, res) => {
  const content = String(req.body.content || '').trim();
  if (!content || content.length > 280) return res.status(400).json({ error: 'Comment must be between 1 and 280 characters.' });
  db.prepare('INSERT INTO comments (post_id, user_id, content) VALUES (?, ?, ?)').run(Number(req.params.id), req.user.id, content);
  res.status(201).json({ posts: getPosts(req.user.id) });
});

app.post('/api/users/:id/follow', requireAuth, (req, res) => {
  const userId = Number(req.params.id);
  if (userId === req.user.id) return res.status(400).json({ error: 'You cannot follow yourself.' });
  const existing = db.prepare('SELECT 1 FROM follows WHERE follower_id = ? AND following_id = ?').get(req.user.id, userId);
  if (existing) db.prepare('DELETE FROM follows WHERE follower_id = ? AND following_id = ?').run(req.user.id, userId);
  else db.prepare('INSERT INTO follows (follower_id, following_id) VALUES (?, ?)').run(req.user.id, userId);
  const currentUser = db.prepare(`${userSelect} WHERE u.id = ?`).get(req.user.id, req.user.id);
  const suggested = db.prepare(`${userSelect} WHERE u.id != ? ORDER BY is_following ASC, followers DESC LIMIT 3`).all(req.user.id, req.user.id);
  res.json({ currentUser, suggested });
});

app.get('/api/users/:id', requireAuth, (req, res) => {
  const user = db.prepare(`${userSelect} WHERE u.id = ?`).get(req.user.id, Number(req.params.id));
  if (!user) return res.status(404).json({ error: 'User not found.' });
  res.json({ user });
});

app.get('/api/admin/stats', requireAuth, (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin access required.' });
  res.json({ users: db.prepare('SELECT COUNT(*) AS count FROM users').get().count, posts: db.prepare('SELECT COUNT(*) AS count FROM posts').get().count, comments: db.prepare('SELECT COUNT(*) AS count FROM comments').get().count });
});

app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.use((error, req, res, next) => {
  if (error instanceof SyntaxError && error.status === 400 && error.type === 'entity.parse.failed') return res.status(400).json({ error: 'The upload request was not valid JSON. Please choose the photo again.' });
  if (error.type === 'entity.too.large') return res.status(413).json({ error: 'That photo is too large. Please choose an image smaller than 8 MB.' });
  next(error);
});

function startServer(port) {
  const server = app.listen(port, () => console.log(`Jan is running at http://localhost:${port}`));
  server.on('error', (error) => {
    if (error.code === 'EADDRINUSE' && !process.env.PORT && port < preferredPort + 10) {
      console.warn(`Port ${port} is busy; trying ${port + 1}.`);
      startServer(port + 1);
      return;
    }
    throw error;
  });
}

startServer(preferredPort);
